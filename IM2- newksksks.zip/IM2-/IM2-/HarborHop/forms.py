from django import forms
from django.contrib.auth.models import User
from .models import Booking, ContactInfo, PassengerDetails, CreateBooking

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    password_confirm = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'password_confirm']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirm = cleaned_data.get("password_confirm")

        if password != password_confirm:
            raise forms.ValidationError("Passwords do not match.")




class LoginForm(forms.ModelForm):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)


class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['vessel', 'departure_port', 'arrival_port', 'price']
        widgets = {
            'price': forms.NumberInput(attrs={'step': 0.01}),
        }

# gwyn's part
class ContactInfoForm(forms.ModelForm):
    class Meta:
        model = ContactInfo
        fields = [
            'contact_person', 'mobile_number', 'email', 'confirm_email', 
            'address', 'receive_notifications'
        ]
        widgets = {
            'address': forms.Textarea(attrs={'rows': 2}),
        }

class PassengerDetailsForm(forms.ModelForm):
    class Meta:
        model = PassengerDetails
        fields = [
            'first_name', 'middle_initial', 'last_name', 'gender',
            'date_of_birth', 'passenger_type', 'nationality'
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }

class ScheduleSelectionForm(forms.Form):
    travel_date = forms.DateField(widget=forms.TextInput(attrs={'type': 'date'}))
    return_date = forms.DateField(required=False, widget=forms.TextInput(attrs={'type': 'date'}))

class CreateBookingForm(forms.ModelForm):
    class Meta:
        model = CreateBooking
        fields = ['ferry', 'travel_date', 'passenger_count', 'is_return']
