from django.db import models

# class Passenger(models.Model):
#     name = models.CharField(max_length=100)
#     gender = models.CharField(max_length=10, null=True, blank=True)
#     age = models.PositiveIntegerField(null=True, blank=True)
#     address = models.CharField(max_length=255)
#     email = models.EmailField(unique=True)
#     phone_number = models.CharField(max_length=15, unique=True) 

#     def __str__(self):
#         return self.name

class Vessel(models.Model):
    name = models.CharField(max_length=100)
    current_port = models.CharField(max_length=100)
    destination_port = models.CharField(max_length=100)
    seating_capacity = models.PositiveIntegerField()

    def __str__(self):
        return self.name

class Port(models.Model):
    name = models.CharField(max_length=100, unique=True)
    capacity = models.PositiveIntegerField()

    def __str__(self):
        return self.name

class Booking(models.Model):
    name = models.CharField(max_length=100, default="Unknown")
    gender = models.CharField(max_length=10, null=True, blank=True)
    age = models.PositiveIntegerField(null=True, blank=True)
    phone_number = models.CharField(max_length=15, unique=True, default="Unknown")
    vessel = models.ForeignKey(Vessel, on_delete=models.CASCADE)
    departure_port = models.ForeignKey(Port, on_delete=models.CASCADE, related_name="departure_tickets")
    arrival_port = models.ForeignKey(Port, on_delete=models.CASCADE, related_name="arrival_tickets")
    price = models.DecimalField(max_digits=10, decimal_places=2)
    date_issued = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('vessel', 'departure_port', 'arrival_port') 

    def __str__(self):
        return f"{self.vessel.name}"
    

# gwyn's part
class ContactInfo(models.Model):
    contact_person = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=15)
    email = models.EmailField()
    confirm_email = models.EmailField()
    address = models.TextField()
    receive_notifications = models.BooleanField(default=False)

    def __str__(self):
        return self.contact_person

class PassengerDetails(models.Model):
    contact_info = models.ForeignKey(ContactInfo, on_delete=models.CASCADE, related_name="passengers")
    first_name = models.CharField(max_length=50)
    middle_initial = models.CharField(max_length=1, blank=True, null=True)
    last_name = models.CharField(max_length=50)
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female')])
    date_of_birth = models.DateField()
    passenger_type = models.CharField(max_length=10, choices=[('Adult', 'Adult'), ('Child', 'Child'), ('Infant', 'Infant')])
    nationality = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
class Ferry(models.Model):
    name = models.CharField(max_length=100)
    company = models.CharField(max_length=100)
    departure_time = models.TimeField()
    duration = models.DurationField()
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    ticket_price = models.DecimalField(max_digits=10, decimal_places=2)
    accommodation_type = models.CharField(max_length=50, choices=[
        ('Economy', 'Economy'),
        ('Business', 'Business'),
        ('VIP', 'VIP'),
    ])
    aircon = models.BooleanField(default=False)
    seat_type = models.CharField(max_length=50, default='Bunk')

    def __str__(self):
        return f"{self.company} - {self.name} ({self.origin} to {self.destination})"


class CreateBooking(models.Model):
    ferry = models.ForeignKey(Ferry, on_delete=models.CASCADE)
    travel_date = models.DateField()
    passenger_count = models.IntegerField()
    is_return = models.BooleanField(default=False)

    def __str__(self):
        return f"Booking for {self.ferry.name} on {self.travel_date}"